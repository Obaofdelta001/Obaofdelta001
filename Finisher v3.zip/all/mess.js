require("./global")

const mess = {
   wait: "*`[ Loading ]` - Wait Kak Lagi Proses*",
   success: "*`[ Success ]` - Berhasil Kak*`",
   on: "*`[ On Feature ]` - Sudah Aktif*", 
   off: "*`[ Off Feature ]` - Sudah Off*",
   query: {
       text: "*`[ QUERY ]` - The text is Where Bro?*",
       link: "*`[ NEED ]` - Where's the link?*",
   },
   error: {
       fitur: "*`[ Error ]` - Sorry Bro, Error Feature, Please Chat with the Bot Developer So It Can Be Fixed Immediately*",
   },
   only: {
       group: "*`[ GROUP ]` - You are a fool🤡. You can also use it in group chat*",
       private: "*`[ PRIVATE ]` - You are a fool🤡. You can also use it in private chat*",
       owner: "*`[ OWNER ]` - You are a fool🫵🤡. It's only for my owner*",
       admin: "*`[ ADMIN ]` - You are a fool🤡. This can only be used by bot owners*",
       badmin: "*`[ BOT ADMIN ]` - You are so foolish. The bot as to be an admin first*",
       premium: "*`[ PREMIUM ]` - You are not a premium member fool 🤡. Contact the owner by using .owner*",
       bugrespon: `Sucess Send Bug☠️`
   }
}

global.mess = mess

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})