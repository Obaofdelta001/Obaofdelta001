//UBAH UBAH DISINI BRO JANGAN LUPA SUBREK YT DELTA TECH//
require("./all/module")
global.owner = "2347054795849" 
global.namaCreator = "Rage" 
global.autoJoin = false
global.antilink = false
global.versisc = '2.0'
global.codeInvite = ""
global.isLink = 'wa.me/2347054795849' 
global.thumb = fs.readFileSync("./thumb.png") 
global.audionya = fs.readFileSync("./all/sound.mp3") 
global.packname = "𝔣𝔦𝔫𝔦𝔰𝔥𝔢𝔯 𝔳3 bugs" 
global.author = "BY LYNN HOST" 
global.jumlah = "5" 
global.namabot = "𝔣𝔦𝔫𝔦𝔰𝔥𝔢𝔯 𝔳3" 
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})